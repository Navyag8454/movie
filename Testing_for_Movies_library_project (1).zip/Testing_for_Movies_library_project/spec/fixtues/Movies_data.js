

//restorents information are stored in this file using Fixtures
var FIXTURES = window.FIXTURES || {};

FIXTURES.movies ={

    movie1:{
        name:"Rajvishnu",
        rating:"4.5",
        genres:"comedy",
        comment:"very Good"
    },
    movie2:{
        name:"spider man no way home",
        rating:"4.8",
        genres:"adventure",
        comment:"excelent movie"
    },
    movie3:{
        name:"Jaggu",
        rating:"4.3",
        genres:"action",
        comment:"Good"
    },
    movie4:{
        name:"Aana",
        rating:"4.5",
        genres:"horror",
        comment:"Good"
    },
}